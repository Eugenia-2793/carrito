<?php
$Titulo = "ver compras";
include_once '../../estructura/cabecera.php';

$datos = data_submitted();
 echo "</br>Por data_submited</br>";
print_r($datos);
 echo "</br>--------------------</br>";

//HACER.
//mando los datos a crear items y luego los listo con el estado de la compra,
//esto queda en vista del usuario como algo q solo puede eliminar.

$AbmObjItem = new AbmCompraItem;
$AbmObjItem->altavariositems($datos);
$filtro= $datos['idcompra'];
$itemsdecompra = $AbmObjItem->buscar($filtro);
// $cantidad = count($itemsdecompra);
// echo $cantidad;
//echo "</br>--------items de compra creados------------</br>";
//print_r($itemsdecompra);

$AbmObjCompra = new AbmCompra;
$filtro= $datos['idcompra'];
$compraunica = $AbmObjCompra->buscar($filtro);
//echo "</br>--------compra unica ------------</br>";
//print_r($compraunica);
//$precio = $AbmObjCompra->precio($itemsdecompra);
//$mostrarCompra = $AbmObjCompra->mostrarCompra($compraunica);




include_once("../../estructura/pie.php");
?>