<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width" />
        <title>How To Show and Hide Div on CheckBox Check or Uncheck
          Using JQuery or Javascript?</title>
    </head>
    <body>
        <label for="chkEmail">
            Do you have Email?&nbsp;
            <input type="checkbox" id="chkEmail" onclick="myFunction()" />
            &nbsp; yes
        </label>
        <hr />
        <div id="div_Email" style="display: none;">
            Email ID:
            <input type="text" id="txtEmail" />
        </div>

        <script>
            function myFunction() {
                var checkBox = document.getElementById("chkEmail");
                var div = document.getElementById("div_Email");
                if (checkBox.checked == true) {
                    div.style.display = "block";
                } else {
                    div.style.display = "none";
                }
            }
        </script>
    </body>
</html>